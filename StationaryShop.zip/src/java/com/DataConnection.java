/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com;

import java.sql.*;

/**
 *
 * @author AAMIR
 */
public class DataConnection {

    public int Dml(String sql) {                                     //dml is to insert ,delete,update queries             
        int re = 0;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/stationary", "root", "aamir");
            Statement st = cn.createStatement();

            re = st.executeUpdate(sql);

        } catch (Exception ex) {

        }
        return re;
    }

  public  ResultSet Dql(String sql) {                                       //dql is for select queries
        ResultSet rs = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/stationary", "root", "aamir");
            Statement st = cn.createStatement();

            rs = st.executeQuery(sql);

        } catch (Exception ex) {

        }
        return rs;
    }
}
