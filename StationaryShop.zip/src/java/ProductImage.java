/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

//import req project
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.*;  //import sql
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

/**
 *
 * @author AAMIR
 */
@WebServlet(urlPatterns = {"/ProductImage"})
//multipart configuration
@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 10, //10 means min part of, image 1024 is to convert to  
        maxFileSize = 1024 * 1024 * 50, // 50 is the max file size
        maxRequestSize = 1024 * 1024 * 100) //request( file+id+data is 100mb)combine karke max image ki request 100 mb ki hogi
public class ProductImage extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            /* TODO output your page here. You may use following sample code. */

            String pid = request.getParameter("t1");           //get id from page
            String cid = request.getParameter("t2");           //get cid from page

            String name = request.getParameter("t3");      //get name from page
            String price = request.getParameter("t4");           //get rate from page

            String description = request.getParameter("t5");           //getdescription from page
            Part filePart = request.getPart("t6");    //get file from page

            InputStream is = null;   //input stream is class to read image file
            if (filePart != null) {
                is = filePart.getInputStream();  //(is) is object of input stream
            }

            Class.forName("com.mysql.jdbc.Driver");
            Connection cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/stationary", "root", "aamir");
            String sql = "insert into product(pid,cid,name,price,description,photo) values (? ,? , ?,?,?,? )"; //? means give value after
            PreparedStatement st = cn.prepareStatement(sql);  //prepare statement means to giv value after and st is object
            st.setInt(1, Integer.parseInt(pid));//pid from page is string type convert into integer
            st.setInt(2, Integer.parseInt(cid));
            st.setString(3, name); //name is 
            st.setInt(4, Integer.parseInt(price));
            st.setString(5, description);
            if (is != null) {
                st.setBlob(6, is);             //object is passed in setblob function
                int re = st.executeUpdate();

                if (re >= 0) {
                    out.println("SAVE SUCCESSFULLY");
                }
            }
        } catch (Exception ex) {
            out.println("Error" + ex);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
